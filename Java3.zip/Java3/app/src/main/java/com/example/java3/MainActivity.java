package com.example.java3;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {
    private String TAG = MainActivity.class.getSimpleName();
public String headlines2;
    private ProgressDialog progressDialog;
    private ListView li;
    public static TextView text1;


    //URL of the json
    private static String url = "https://raw.githubusercontent.com/bbc/news-and-weather-apps-coding-challenge-trainees/master/headlines.json";

    ArrayList<HashMap<String, String>> headlinesList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        headlinesList = new ArrayList<>();
        text1 = findViewById(R.id.headline);
        li = (ListView) findViewById(R.id.listView);
        li.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
               Intent intent = new Intent(MainActivity.this,Activity2.class);
//               intent.putExtra("headline",li.getItemAtPosition(position).toString());
               startActivity(intent);
            }
        });

//       click.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//      @Override
//      public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//
//      }
//  });
        new GetHeadlines().execute();
    }


    class GetHeadlines extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            //loading
            progressDialog = new ProgressDialog(MainActivity.this);
            progressDialog.setMessage("Loading");
            progressDialog.setCancelable(false);
            progressDialog.show();
        }

        @Override
        protected Void doInBackground(Void... voids) {
            HttpHandler hb = new HttpHandler();
            String jsonStr = hb.makeServiceCall(url);
            Log.e(TAG, "response from url" + jsonStr);

            if (jsonStr != null) {
                try {
                    JSONObject jsonObject = new JSONObject(jsonStr);
                    JSONArray headlines = jsonObject.getJSONArray("headlines");
                    //loop through all headlines

                    for (int i = 0; i < headlines.length(); i++) {
                        JSONObject h = headlines.getJSONObject(i);
                        String headline = h.getString("headline");
                        String update = h.getString("updated");
                        String yourSeconds = update;
                        long num = Long.parseLong(yourSeconds);
                        Date date = new java.util.Date(num * 1000L);

                        SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss z");
                        sdf.setTimeZone(java.util.TimeZone.getTimeZone("GMT"));
                        String formattedDate = sdf.format(date);
                        String introduction = h.getString("introduction");
                        HashMap<String, String> he = new HashMap<>();

                        he.put("headline", headline);
                        he.put("updated", formattedDate);
                        he.put("introduction", introduction);

                        headlinesList.add(he);

                    }
                } catch (final JSONException e) {
                    Log.e(TAG, "Json pasing error" + e.getMessage());
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(MainActivity.this,
                                    "Json Parsing error 1" +
                                            e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
                    e.printStackTrace();
                }
            } else {
                Log.e(TAG, "Couldn't get json from server");
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(MainActivity.this,
                                "Couldnt get json from server.",
                                Toast.LENGTH_SHORT).show();
                    }
                });
            }


            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);

            //dismiss dialog

            if (progressDialog.isShowing()) {
                progressDialog.dismiss();
            }
            ListAdapter adapter = new SimpleAdapter(MainActivity.this, headlinesList,
                    R.layout.list_item, new String[]{"headline", "updated"}, new int[]{R.id.headline, R.id.updated});
            li.setAdapter(adapter);
//            a.notifyDataSetChanged();


        }
    }
}

