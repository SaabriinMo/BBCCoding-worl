package com.example.java3;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.android.volley.RequestQueue;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

public class Activity2 extends AppCompatActivity {
    public static TextView text1;
    public static TextView text2;
    public static TextView text3;
    String data="";

    int position;
    RequestQueue rq;


    ListView li;
    private ProgressDialog progressDialog;
    ArrayList<HashMap<String, String>> headlinesList;
    private String TAG = MainActivity.class.getSimpleName();
    RelativeLayout rt;
    public static String headliness, formattedDate, introduction;
    private static String url = "https://raw.githubusercontent.com/bbc/news-and-weather-apps-coding-challenge-trainees/master/headlines.json";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        headlinesList = new ArrayList<>();
        setContentView(R.layout.activity_another);
        text1 = findViewById(R.id.headlineText);
        text2 = findViewById(R.id.updateText);
        text3 = findViewById(R.id.introText);
        new fetchData().execute();

    }
    class fetchData extends AsyncTask<Void, Void, Void> {

        //    String data = "";
//    String dataParsed = "";
//    String dataParsed2 = "";
//    String dataParsed3 = "";
//    String SingleParsed = "";

        public String headliness, formattedDate, introduction;
        int counter;


        @Override
        protected Void doInBackground(Void... voids) {



            try {

                HttpHandler hb = new HttpHandler();
                String jsonStr = hb.makeServiceCall(url);
                Log.e(TAG, "response from url" + jsonStr);

                if (jsonStr != null) {

                    JSONObject HeadlineData = new JSONObject(jsonStr);
                    JSONArray headlines = HeadlineData.getJSONArray("headlines");

                    for (int i = 0; i < HeadlineData.length(); i++) {
                        JSONObject h1 = headlines.getJSONObject(i);
                            headliness = h1.getString("headline");
                            String update = h1.getString("updated");
                            String yourSeconds = update;
                            long num = Long.parseLong(yourSeconds);
                            Date date = new java.util.Date(num * 1000L);
                            SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss z");
                            sdf.setTimeZone(java.util.TimeZone.getTimeZone("GMT"));
                            formattedDate = sdf.format(date);
                            introduction = h1.getString("introduction");
                            HashMap<String, String> he = new HashMap<>();

                            he.put("headline", headliness);
                            he.put("updated", formattedDate);
                            he.put("introduction", introduction);



                       headlinesList.add(he);

                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            text1.setText(this.headliness);
            text2.setText(this.formattedDate);
            text3.setText(this.introduction);


        }
    }



}


