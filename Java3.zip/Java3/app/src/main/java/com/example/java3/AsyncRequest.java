package com.example.java3;

import org.apache.http.client.fluent.Async;
import org.apache.http.client.fluent.Content;
import org.apache.http.client.fluent.Request;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.concurrent.FutureCallback;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;


public class AsyncRequest {
    public static void main(String[] args) throws Exception {
        URIBuilder urlBuilder = new URIBuilder()
                .setScheme("http")
                .setHost("raw.githubusercontent.com")
                .setPath("/bbc/news-and-weather-apps-coding-challenge-trainees/master/analytics?event=load&time=100");

        final int nThreads = 3; // no. of threads in the pool
        final int timeout = 0; // connection time out in milliseconds

        URI ur = null;
        try {
            ur = urlBuilder.build();
        } catch (URISyntaxException use) {
            use.printStackTrace();
        }

        ExecutorService executorService = Executors.newFixedThreadPool(nThreads);
        Async async = Async.newInstance().use(executorService);
        final Request request = Request.Get(ur).connectTimeout(timeout);

        Future<Content> future = async.execute(request, new FutureCallback<Content>() {
            public void failed(final Exception e) {
                System.out.println("Request failed: " + request);
                System.exit(1);
            }

            public void completed(final Content content) {
                System.out.println("Request completed: " + request);
                System.out.println(content.asString());
                System.exit(0);
            }

            public void cancelled() {
            }
        });

        System.out.println("Request submitted");

    }

}